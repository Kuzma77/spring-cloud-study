package com.soft1851.springboot.contentcenter.controller;

import com.soft1851.springboot.contentcenter.domain.dto.ShareDto;
import com.soft1851.springboot.contentcenter.domain.dto.UserDto;
import com.soft1851.springboot.contentcenter.domain.entity.Share;
import com.soft1851.springboot.contentcenter.service.ShareService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wl_sun
 * @description TODO
 * @Data 2020/9/28
 */
@RestController
@RequestMapping(value = "/share")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ShareController {

    private final ShareService shareService;
    private final RestTemplate restTemplate;

    @GetMapping(value = "/all")
    public List<ShareDto> getAllShare(){
        List<Share> shares = shareService.getAllShare();
        List<ShareDto> shareDtoList = new ArrayList<>();
        shares.forEach(share -> {
            System.out.println(share.getTitle());
            UserDto userDto =restTemplate.getForObject("http://10.40.147.17:8082/user/{id}",UserDto.class,share.getUserId());
            assert userDto != null;
            ShareDto shareDto = ShareDto.builder()
                    .share(share)
                    .userDto(userDto)
                    .build();
            shareDtoList.add(shareDto);
        });
        return shareDtoList;
    }

}
