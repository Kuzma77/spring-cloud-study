package com.soft1851.springboot.contentcenter.mapper;

import com.soft1851.springboot.contentcenter.domain.entity.Share;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author wl_sun
 * @description TODO
 * @Data 2020/9/28
 */
public interface ShareMapper extends Mapper<Share> {
}
