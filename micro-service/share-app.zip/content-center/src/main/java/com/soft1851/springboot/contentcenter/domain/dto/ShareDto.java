package com.soft1851.springboot.contentcenter.domain.dto;

import com.soft1851.springboot.contentcenter.domain.entity.Share;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author wl_sun
 * @description TODO
 * @Data 2020/9/29
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShareDto {
    private UserDto userDto;
    private Share share;
}
