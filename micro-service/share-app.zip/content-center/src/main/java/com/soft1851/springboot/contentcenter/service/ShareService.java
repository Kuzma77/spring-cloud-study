package com.soft1851.springboot.contentcenter.service;

import com.soft1851.springboot.contentcenter.domain.entity.Share;
import com.soft1851.springboot.contentcenter.mapper.ShareMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author wl_sun
 * @description TODO
 * @Data 2020/9/28
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ShareService {


    private final ShareMapper shareMapper;

    public List<Share> getAllShare() {
        return shareMapper.selectAll();
    }
}
