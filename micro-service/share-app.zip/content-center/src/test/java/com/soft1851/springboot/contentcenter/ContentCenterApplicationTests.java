package com.soft1851.springboot.contentcenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContentCenterApplicationTests {

    @Test
    void contextLoads() {
    }

}
