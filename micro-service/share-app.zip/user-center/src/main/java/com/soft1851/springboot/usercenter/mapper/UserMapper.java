package com.soft1851.springboot.usercenter.mapper;

import com.soft1851.springboot.usercenter.domain.entity.User;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author wl_sun
 * @description TODO
 * @Data 2020/9/29
 */
public interface UserMapper extends Mapper<User> {

}
